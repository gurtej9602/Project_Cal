const btn1 = document.getElementById("btn1")
const btn2 = document.getElementById("btn2")
const btn3 = document.getElementById("btn3")
const btn4 = document.getElementById("btn4")
const btn5 = document.getElementById("btn5")

const op1 = document.getElementById("op1")
const op2 = document.getElementById("op2")
const op3 = document.getElementById("op3")
const op4 = document.getElementById("op4")
const op5 = document.getElementById("op5")
const op6 = document.getElementById("op6")

const pie = 3.14;
//cube
document.getElementById("submitbtn").onclick = function(){
   if (btn1.checked && op1.checked){
     document.getElementById("head1").innerHTML =  "CUBE "  ;  
     let a1 = window.prompt("plz enter the side");
     let v1 = (a1*a1)*a1
     document.getElementById("lable1").innerHTML = "volume= " + v1;
     console.log(v1);
   }
   else if(btn2.checked && op1.checked){
      document.getElementById("head1").innerHTML =  "CUBE " ;
      let a2 = window.prompt("plz enter the side");
      let v2 =6*(a2*a2);
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op1.checked){
      document.getElementById("head1").innerHTML =  "cube" 
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window. prompt("plz enter the height");
      let S = (4*L) + (4*B) + (4*H)
      let v3 = S;
      document.getElementById("lable3").innerHTML = "peremiter= " + v3;
      console.log(v3);
   }
   else if(btn4.checked && op1.checked){
      document.getElementById("head1").innerHTML =  "cube"
      let a3 = window.prompt("plz enter the side");
      let v4 =6*(a3*a3);
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op1.checked){
      document.getElementById("head1").innerHTML =  "cube"
      let a4 = window.prompt("plz enter the side");
      let v5 =6*(a4*a4);
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   }
   //CUBOID
   else if (btn1.checked && op2.checked){
      document.getElementById("head1").innerHTML =  "CUBOID "  ;  
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window. prompt("plz enter the height");
      let v1 = L * B * H;
      document.getElementById("lable1").innerHTML = "volume= " + v1 ;
      console.log(v1);
   }
   else if(btn2.checked && op2.checked){
      document.getElementById("head1").innerHTML =  "CUBOID " ;
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window.prompt("plz enter the height");
      let v2 = 2*(L * B) + 2 * (B * H) + 2 * (H * L);
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op2.checked){
      document.getElementById("head1").innerHTML =  "CUBOID" 
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window.prompt("plz enter the height");
      let v3 = (4 * L) + (4 * B) + (4 * H);
      document.getElementById("lable3").innerHTML = "peremiter= " + v3;
      console.log(v3);
   }
   else if(btn4.checked && op2.checked){
      document.getElementById("head1").innerHTML =  "CUBOID"
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window.prompt("plz enter the height");
      let S = (2 * H);
      let v4 = ((S * L) + (S * B));
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op2.checked){
      document.getElementById("head1").innerHTML =  "CUBOID"
      let L = window.prompt("plz enter the length");
      let B = window.prompt("plz enter the breath");
      let H = window.prompt("plz enter the height");
      let v5 =(2 *(L * B) + 2 * (B * H) + 2 * (H * L));
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   }
   //CYLINDER
   else if (btn1.checked && op3.checked){
      document.getElementById("head1").innerHTML =  "CYLINDER "  ;  
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let S = R * R
      let v1 = (pie * S * H)
      document.getElementById("lable1").innerHTML = "volume= " + v1 ;
      console.log(v1);
   }
   else if(btn2.checked && op3.checked){
      document.getElementById("head1").innerHTML =  "CYLINDER " ;
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let S = R * R
      let v2 = (2 * (pie * R * H) + 2 * (pie * S))
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op3.checked){
      document.getElementById("head1").innerHTML =  "CYLINDER" 
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let v3 = (4 * R ) + (2 * H);
      document.getElementById("lable3").innerHTML = "peremiter= " + v3;
      console.log(v3);
   }
   else if(btn4.checked && op3.checked){
      document.getElementById("head1").innerHTML =  "CYLINDER"
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let v4 = (2 * pie * R * H);
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op3.checked){
      document.getElementById("head1").innerHTML =  "CYLINDER"
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let S = (R + H);
      let v5 = (2 * pie * R * S);
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   }
   //CONE
   else if (btn1.checked && op4.checked){
      document.getElementById("head1").innerHTML =  "CONE"  ;  
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let S = R * R;
      let P = (pie * S * H);
      let v1 = P / 3;
      document.getElementById("lable1").innerHTML = "volume= " + v1 ;
      console.log(v1);
   }
   else if(btn2.checked && op4.checked){
      document.getElementById("head1").innerHTML =  "CONE " ;
      let R = window.prompt("plz enter the radius");
      let H = window.prompt("plz enter the hight");
      let S = (H * H + R * R);
      let P = (Math.sqrt(S) + R);
      let v2 = (pie * R * P);
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op4.checked){
      document.getElementById("head1").innerHTML =  "CONE" 
      let R = window.prompt("plz enter the radius");
      let v3 = (2 * pie * R);
      document.getElementById("lable3").innerHTML = "peremiter= " + v3;
      console.log(v3);
   }
   else if(btn4.checked && op4.checked){
      document.getElementById("head1").innerHTML =  "CONE"
      let R = window.prompt("plz enter the radius");
      let SL = window.prompt("plz enter the slant hight");
      let v4 = (pie * R * SL);
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op4.checked){
      document.getElementById("head1").innerHTML =  "CONE"
      let R = window.prompt("plz enter the radius");
      let SL = window.prompt("plz enter the slant hight");
      let S = (R + SL)
      let v5 = (pie * R * S);
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   }
   //SPHERE
   else if (btn1.checked && op5.checked){
      document.getElementById("head1").innerHTML =  "SPHERE"  ;  
      let R = window.prompt("plz enter the radius");
      let S = R * R * R;
      let P = (4 * pie * S);
      let v1 = P / 3;
      document.getElementById("lable1").innerHTML = "volume= " + v1 ;
      console.log(v1);
   }
   else if(btn2.checked && op5.checked){
      document.getElementById("head1").innerHTML =  "SPHERE " ;
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v2 = (4 * pie * S);
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op5.checked){
      document.getElementById("head1").innerHTML =  "SPHERE" 
      document.getElementById("lable3").innerHTML = " no peremiter" ;
      console.log("NO PARAMETER");
   }
   else if(btn4.checked && op5.checked){
      document.getElementById("head1").innerHTML =  "SPHERE"
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v4 = (4 * pie * S);
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op5.checked){
      document.getElementById("head1").innerHTML =  "SPHERE"
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v5 = (4 * pie * S);
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   }
   //HEMISPHRE
   else if (btn1.checked && op6.checked){
      document.getElementById("head1").innerHTML =  "HEMISPHRE"  ;  
      let R = window.prompt("plz enter the radius");
      let S = R * R * R;
      let P = (2 * pie * S);
      let v1 = P / 3;
      document.getElementById("lable1").innerHTML = "volume= " + v1 ;
      console.log(v1);
   }
   else if(btn2.checked && op6.checked){
      document.getElementById("head1").innerHTML =  "HEMISPHRE " ;
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v2 = (3 * pie * S);
      document.getElementById("lable2").innerHTML = "area= " + v2;
      console.log(v2);
   }
   else if(btn3.checked && op6.checked){
      document.getElementById("head1").innerHTML =  "HEMISPHRE" 
      document.getElementById("lable3").innerHTML = " no peremiter" ;
      console.log("NO PARAMETER");
   }
   else if(btn4.checked && op6.checked){
      document.getElementById("head1").innerHTML =  "HEMISPHRE"
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v4 = (2 * pie * S);
      document.getElementById("lable4").innerHTML = "csa= " + v4;
      console.log(v4);
   }
   else if(btn5.checked && op6.checked){
      document.getElementById("head1").innerHTML =  "HEMISPHRE"
      let R = window.prompt("plz enter the radius");
      let S = R * R;
      let v5 = (3 * pie * S);
      document.getElementById("lable5").innerHTML = "tsa= " + v5;
      console.log(v5);
   } 

}